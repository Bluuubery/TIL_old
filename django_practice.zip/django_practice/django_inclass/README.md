# 8기 Django 라이브 코드

| Day  | Subject                      |
| ---- | ---------------------------- |
| 01   | Django Intro                 |
| 02   | Django Model                 |
| 04   | Django Form                  |
| 05   | Django Authentication System |
| 07   | Django managing staticfiles  |
| 08   | Django REST Framework        |

